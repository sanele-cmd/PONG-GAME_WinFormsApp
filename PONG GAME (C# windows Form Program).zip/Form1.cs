﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace u25287682_INF154_Practical1
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
            btnGoal2.Enabled = false;
            btnReset.Enabled = false;
        }

        private void btnGoal1_Click(object sender, EventArgs e)
        {
            pnlBall.Top = 330;
            pnlBall.Left = 715;
            pnlPanel1.Top = 100;
            pnlPanel2.Top = 80;


            lblP1Chant1.Text = "SCORE!";
            lblP1Chant2.Text = "Whoooooooo!";
            lblP2chant1.Text = "Don't worry, you got this!";
            lblP2Chant2.Text = "Let's Go Player 2!";
            lblCurrentscore.Text = "Current Score 1 - 0 (5 : 32)";
            this.BackColor = Color.LightGreen;

            btnGoal2.Enabled = true;
            btnGoal1.Enabled = false;
            btnReset.Enabled = true;

        }

        private void btnGoal2_Click(object sender, EventArgs e)
        {
            pnlBall.Top = 330;
            pnlBall.Left = 29;
            pnlPanel1.Top = 80;
            pnlPanel2.Top = 100;

            lblP1Chant1.Text = "Don't give up!";
            lblP1Chant2.Text = "Come on man!";
            lblP2chant1.Text = "Way to go , Player 2!";
            lblP2Chant2.Text = "Well done!";

            lblCurrentscore.Text = "Current Score 1 - 1 (10 : 59)";
            this.BackColor = Color.Blue;

            btnGoal2.Enabled = false;
            btnGoal1.Enabled = false;
            btnReset.Enabled = true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            pnlBall.Top = 196;
            pnlBall.Left = 374;
            pnlPanel1.Top = 116;
            pnlPanel2.Top = 116;

            lblP1Chant1.Text = "Shoot now!";
            lblP1Chant2.Text = "Please score!";
            lblP2chant1.Text = "Defense!";
            lblP2Chant2.Text = "Defense!";

            lblCurrentscore.Text = "Current Score 0 - 0";
            this.BackColor = Color.DarkGray;

            btnGoal1.Enabled = true;
            btnGoal2.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    
}
