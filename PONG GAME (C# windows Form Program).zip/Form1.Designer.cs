﻿namespace u25287682_INF154_Practical1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPanel1 = new System.Windows.Forms.Panel();
            this.pnlPanel2 = new System.Windows.Forms.Panel();
            this.pnlBall = new System.Windows.Forms.Panel();
            this.btnGoal1 = new System.Windows.Forms.Button();
            this.btnGoal2 = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblPong = new System.Windows.Forms.Label();
            this.lblCurrentscore = new System.Windows.Forms.Label();
            this.lblP1Chant1 = new System.Windows.Forms.Label();
            this.lblP1Chant2 = new System.Windows.Forms.Label();
            this.lblP2chant1 = new System.Windows.Forms.Label();
            this.lblP2Chant2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pnlPanel1
            // 
            this.pnlPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pnlPanel1.Location = new System.Drawing.Point(28, 102);
            this.pnlPanel1.Name = "pnlPanel1";
            this.pnlPanel1.Size = new System.Drawing.Size(32, 233);
            this.pnlPanel1.TabIndex = 0;
            // 
            // pnlPanel2
            // 
            this.pnlPanel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.pnlPanel2.Location = new System.Drawing.Point(704, 95);
            this.pnlPanel2.Name = "pnlPanel2";
            this.pnlPanel2.Size = new System.Drawing.Size(35, 240);
            this.pnlPanel2.TabIndex = 1;
            // 
            // pnlBall
            // 
            this.pnlBall.BackColor = System.Drawing.Color.White;
            this.pnlBall.Location = new System.Drawing.Point(374, 196);
            this.pnlBall.Name = "pnlBall";
            this.pnlBall.Size = new System.Drawing.Size(23, 24);
            this.pnlBall.TabIndex = 2;
            // 
            // btnGoal1
            // 
            this.btnGoal1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnGoal1.Location = new System.Drawing.Point(200, 355);
            this.btnGoal1.Name = "btnGoal1";
            this.btnGoal1.Size = new System.Drawing.Size(75, 23);
            this.btnGoal1.TabIndex = 3;
            this.btnGoal1.Text = "Goal 1";
            this.btnGoal1.UseVisualStyleBackColor = false;
            this.btnGoal1.Click += new System.EventHandler(this.btnGoal1_Click);
            // 
            // btnGoal2
            // 
            this.btnGoal2.Location = new System.Drawing.Point(388, 355);
            this.btnGoal2.Name = "btnGoal2";
            this.btnGoal2.Size = new System.Drawing.Size(75, 23);
            this.btnGoal2.TabIndex = 4;
            this.btnGoal2.Text = "Goal 2";
            this.btnGoal2.UseVisualStyleBackColor = true;
            this.btnGoal2.Click += new System.EventHandler(this.btnGoal2_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(564, 355);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(62, 23);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnClose.Location = new System.Drawing.Point(388, 398);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 26);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblPong
            // 
            this.lblPong.AutoSize = true;
            this.lblPong.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPong.Location = new System.Drawing.Point(308, 19);
            this.lblPong.Name = "lblPong";
            this.lblPong.Size = new System.Drawing.Size(234, 25);
            this.lblPong.TabIndex = 7;
            this.lblPong.Text = "Pong Game Highlight";
            // 
            // lblCurrentscore
            // 
            this.lblCurrentscore.AutoSize = true;
            this.lblCurrentscore.Location = new System.Drawing.Point(369, 64);
            this.lblCurrentscore.Name = "lblCurrentscore";
            this.lblCurrentscore.Size = new System.Drawing.Size(94, 13);
            this.lblCurrentscore.TabIndex = 8;
            this.lblCurrentscore.Text = "Current score 0 - 0";
            // 
            // lblP1Chant1
            // 
            this.lblP1Chant1.AutoSize = true;
            this.lblP1Chant1.Location = new System.Drawing.Point(45, 36);
            this.lblP1Chant1.Name = "lblP1Chant1";
            this.lblP1Chant1.Size = new System.Drawing.Size(63, 13);
            this.lblP1Chant1.TabIndex = 9;
            this.lblP1Chant1.Text = "Shoot Now!";
            // 
            // lblP1Chant2
            // 
            this.lblP1Chant2.AutoSize = true;
            this.lblP1Chant2.Location = new System.Drawing.Point(45, 385);
            this.lblP1Chant2.Name = "lblP1Chant2";
            this.lblP1Chant2.Size = new System.Drawing.Size(71, 13);
            this.lblP1Chant2.TabIndex = 10;
            this.lblP1Chant2.Text = "Please score!";
            // 
            // lblP2chant1
            // 
            this.lblP2chant1.AutoSize = true;
            this.lblP2chant1.Location = new System.Drawing.Point(670, 35);
            this.lblP2chant1.Name = "lblP2chant1";
            this.lblP2chant1.Size = new System.Drawing.Size(50, 13);
            this.lblP2chant1.TabIndex = 11;
            this.lblP2chant1.Text = "Defense!";
            // 
            // lblP2Chant2
            // 
            this.lblP2Chant2.AutoSize = true;
            this.lblP2Chant2.Location = new System.Drawing.Point(670, 385);
            this.lblP2Chant2.Name = "lblP2Chant2";
            this.lblP2Chant2.Size = new System.Drawing.Size(50, 13);
            this.lblP2Chant2.TabIndex = 12;
            this.lblP2Chant2.Text = "Defense!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblP2Chant2);
            this.Controls.Add(this.lblP2chant1);
            this.Controls.Add(this.lblP1Chant2);
            this.Controls.Add(this.lblP1Chant1);
            this.Controls.Add(this.lblCurrentscore);
            this.Controls.Add(this.lblPong);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnGoal2);
            this.Controls.Add(this.btnGoal1);
            this.Controls.Add(this.pnlBall);
            this.Controls.Add(this.pnlPanel2);
            this.Controls.Add(this.pnlPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlPanel1;
        private System.Windows.Forms.Panel pnlPanel2;
        private System.Windows.Forms.Panel pnlBall;
        private System.Windows.Forms.Button btnGoal1;
        private System.Windows.Forms.Button btnGoal2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblPong;
        private System.Windows.Forms.Label lblCurrentscore;
        private System.Windows.Forms.Label lblP1Chant1;
        private System.Windows.Forms.Label lblP1Chant2;
        private System.Windows.Forms.Label lblP2chant1;
        private System.Windows.Forms.Label lblP2Chant2;
    }
}

